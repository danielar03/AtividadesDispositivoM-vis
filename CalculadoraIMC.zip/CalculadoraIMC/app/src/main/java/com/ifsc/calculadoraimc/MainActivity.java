package com.ifsc.calculadoraimc;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText editTextPeso;
    private EditText editTextAltura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextPeso = findViewById(R.id.editTextPeso);
        editTextAltura = findViewById(R.id.editTextAltura);
        Button buttonCalcular = findViewById(R.id.buttonCalcular);

        buttonCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularIMC();
            }
        });
    }
    private void calcularIMC() {
        String pesoStr = editTextPeso.getText().toString();
        String alturaStr = editTextAltura.getText().toString();
        /* Calculo do IMC*/
        if (!pesoStr.isEmpty() && !alturaStr.isEmpty()) {
            float peso = Float.parseFloat(pesoStr);
            float altura = Float.parseFloat(alturaStr);
            float imc = peso / (altura * altura);
            String classificacao = classificarIMC(imc);

            Intent intent = new Intent(MainActivity.this, MainActivity.class);
            intent.putExtra("IMC", imc);
            intent.putExtra("Classificacao", classificacao);
            startActivity(intent);
        }
    }

    private String classificarIMC(float imc) {
        if (imc < 18.5) return "Abaixo do peso";
        else if (imc < 24.9) return "Peso normal";
        else if (imc < 29.9) return "Sobrepeso";
        else if (imc < 34.9) return "Obesidade grau 1";
        else if (imc < 39.9) return "Obesidade grau 2";
        else return "Obesidade grau 3";
    }
}