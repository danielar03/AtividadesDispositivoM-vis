package com.ifsc.calculadoraimc;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivityB extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_b);

        TextView textViewResultado = findViewById(R.id.textViewResultado);
        TextView textViewClassificacao = findViewById(R.id.textViewClassificacao);
        Button buttonVoltar = findViewById(R.id.buttonVoltar);

        Intent intent = getIntent();
        float imc = intent.getFloatExtra("IMC", 0);
        String classificacao = intent.getStringExtra("Classificacao");

        textViewResultado.setText(String.format("Seu IMC é: %.2f", imc));
        textViewClassificacao.setText(classificacao);

        buttonVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); /*Volta para a tela anterior*/
            }
        });
    }
}